solutionlist data/j30hrs.mm
================================================================================
Par     Inst    Makespan        Date                    Author
================================================================================
7	8	47		Fri Jan 17 10:56:32 2003  K. Nonobe and T. Ibaraki
8	6	46		Mon Feb 21 16:26:36 2000  A. Siegner
9	1	31		Sat Aug 30 04:11:36 1997  Soenke Hartmann
9	2	27		Mon Sep  8 12:00:06 1997  Soenke Hartmann
9	3	34		Mon Sep  8 12:00:11 1997  Soenke Hartmann
9	4	30		Mon Sep  8 12:00:16 1997  Soenke Hartmann
9	5	27		Thu Jun 25 12:11:14 1998  K. Nonobe and T. Ibaraki
9	6	31		Thu Jun 25 12:04:38 1998  K. Nonobe and T. Ibaraki
9	7	35		Sat Aug 30 04:12:04 1997  Soenke Hartmann
9	8	26		Thu Jun 25 12:04:43 1998  K. Nonobe and T. Ibaraki
9	9	32		Sat Aug 30 04:12:13 1997  Soenke Hartmann
9	10	25		Thu Jun 25 12:04:29 1998  K. Nonobe and T. Ibaraki
10	1	26		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
10	2	28		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
10	3	24		Sat Aug 30 04:12:22 1997  Soenke Hartmann
10	4	36		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
10	5	33		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
10	6	25		Sat Aug 30 04:12:27 1997  Soenke Hartmann
10	7	22		Sat Aug 30 04:12:31 1997  Soenke Hartmann
10	8	31		Sat Aug 30 04:12:36 1997  Soenke Hartmann
10	9	38		Mon Sep  8 12:00:30 1997  Soenke Hartmann
10	10	32		Mon Sep  8 12:00:34 1997  Soenke Hartmann
11	1	35		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
11	2	28		Sat Aug 30 04:12:45 1997  Soenke Hartmann
11	3	31		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
11	4	35		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
11	5	35		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
11	6	33		Sat Aug 30 04:12:49 1997  Soenke Hartmann
11	7	32		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
11	8	30		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
11	9	26		Sat Aug 30 04:12:54 1997  Soenke Hartmann
11	10	35		Sat Aug 30 04:12:58 1997  Soenke Hartmann
12	1	29		Sat Aug 30 04:13:03 1997  Soenke Hartmann
12	2	31		Sat Aug 30 04:13:08 1997  Soenke Hartmann
12	3	34		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
12	4	29		Mon Sep  8 12:00:39 1997  Soenke Hartmann
12	5	25		Sat Aug 30 04:13:17 1997  Soenke Hartmann
12	6	34		Sat Aug 30 04:13:21 1997  Soenke Hartmann
12	7	27		Sat Aug 30 04:13:26 1997  Soenke Hartmann
12	8	28		Sat Aug 30 04:13:30 1997  Soenke Hartmann
12	9	22		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
12	10	28		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
13	1	37		Mon Sep  8 12:00:44 1997  Soenke Hartmann
13	2	40		Thu Jun 25 12:04:53 1998  K. Nonobe and T. Ibaraki
13	3	41		Thu Dec 17 04:14:03 1998  Soenke Hartmann
13	4	41		Sun Feb  6 00:20:05 2011  L. F. Muller
13	5	38		Fri May 21 04:00:06 1999  M. Mika
13	6	38		Thu Sep 24 10:34:59 1998  K. Nonobe and T. Ibaraki
13	7	41		Thu Jun 25 12:05:15 1998  K. Nonobe and T. Ibaraki
13	8	28		Sat Aug 30 04:14:07 1997  Soenke Hartmann
13	9	30		Thu Sep 24 10:35:07 1998  K. Nonobe and T. Ibaraki
13	10	42		Fri Sep  3 01:20:08 2010  Shixin Liu
14	1	37		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
14	2	32		Mon Sep  8 12:01:13 1997  Soenke Hartmann
14	3	30		Thu Jun 10 04:00:06 1999  M. Mika
14	4	34		Sat Aug 30 04:14:31 1997  Soenke Hartmann
14	5	26		Thu Sep 24 10:35:14 1998  K. Nonobe and T. Ibaraki
14	6	29		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
14	7	34		Sat Aug 30 04:14:35 1997  Soenke Hartmann
14	8	41		Sat Aug 30 04:14:40 1997  Soenke Hartmann
14	9	31		Sat Aug 30 04:14:44 1997  Soenke Hartmann
14	10	29		Sat Aug 30 04:14:49 1997  Soenke Hartmann
15	1	40		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
15	2	34		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
15	3	33		Sat Aug 30 04:14:53 1997  Soenke Hartmann
15	4	30		Sat Aug 30 04:14:58 1997  Soenke Hartmann
15	5	24		Mon Sep  8 12:01:28 1997  Soenke Hartmann
15	6	22		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
15	7	27		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
15	8	23		Sat Aug 30 04:15:07 1997  Soenke Hartmann
15	9	28		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
15	10	38		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
16	1	27		Sat Aug 30 04:15:12 1997  Soenke Hartmann
16	2	41		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
16	3	23		Sat Aug 30 04:15:16 1997  Soenke Hartmann
16	4	19		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
16	5	30		Sat Aug 30 04:15:21 1997  Soenke Hartmann
16	6	30		Sat Aug 30 04:15:25 1997  Soenke Hartmann
16	7	22		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
16	8	25		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
16	9	24		Sat Aug 30 04:15:30 1997  Soenke Hartmann
16	10	32		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
17	1	34		Thu Jun 25 12:00:29 1998  K. Nonobe and T. Ibaraki
17	2	26		Fri Oct 31 12:00:07 1997  K.Bouleimen
17	3	33		Sat Aug 30 04:15:44 1997  Soenke Hartmann
17	4	39		Thu Jun 25 12:00:34 1998  K. Nonobe and T. Ibaraki
17	5	29		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
17	6	33		Thu Jun 25 12:00:39 1998  K. Nonobe and T. Ibaraki
17	7	32		Fri Oct 31 12:00:12 1997  K.Bouleimen
17	8	31		Thu Jun 25 12:00:43 1998  K. Nonobe and T. Ibaraki
17	9	34		Thu Jun 25 12:00:48 1998  K. Nonobe and T. Ibaraki
17	10	26		Mon Sep  8 12:01:33 1997  Soenke Hartmann
18	1	28		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
18	2	33		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
18	3	35		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
18	4	31		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
18	5	21		Sat Aug 30 04:16:15 1997  Soenke Hartmann
18	6	25		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
18	7	35		Sat Aug 30 04:16:20 1997  Soenke Hartmann
18	8	18		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
18	9	25		Mon Sep  8 12:01:37 1997  Soenke Hartmann
18	10	33		Sat Aug 30 04:16:29 1997  Soenke Hartmann
19	1	35		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
19	2	21		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
19	3	31		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
19	4	30		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
19	5	27		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
19	6	24		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
19	7	36		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
19	8	34		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
19	9	25		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
19	10	29		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
20	1	30		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
20	2	25		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
20	3	27		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
20	4	35		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
20	5	29		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
20	6	24		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
20	7	30		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
20	8	33		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
20	9	26		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
20	10	28		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
21	1	38		Fri Oct 31 12:00:17 1997  K.Bouleimen
21	2	34		Thu Jun 25 12:05:43 1998  K. Nonobe and T. Ibaraki
21	3	36		Thu Jun 25 12:05:47 1998  K. Nonobe and T. Ibaraki
21	4	37		Thu Jun 25 12:00:52 1998  K. Nonobe and T. Ibaraki
21	5	37		Fri Oct 31 12:00:27 1997  K.Bouleimen
21	6	33		Thu Dec 17 04:20:21 1998  Soenke Hartmann
21	7	36		Fri Oct 31 12:00:32 1997  K.Bouleimen
21	8	44		Thu Jun 25 12:01:01 1998  K. Nonobe and T. Ibaraki
21	9	32		Sat Aug 30 04:17:10 1997  Soenke Hartmann
21	10	45		Thu Dec 17 04:20:38 1998  Soenke Hartmann
22	1	26		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
22	2	36		Thu Jun 25 12:01:07 1998  K. Nonobe and T. Ibaraki
22	3	25		Sat Aug 30 04:17:24 1997  Soenke Hartmann
22	4	26		Sat Aug 30 04:17:29 1997  Soenke Hartmann
22	5	30		Thu Jun 25 12:06:10 1998  K. Nonobe and T. Ibaraki
22	6	31		Sat Aug 30 04:17:38 1997  Soenke Hartmann
22	7	38		Sat Aug 30 04:17:42 1997  Soenke Hartmann
22	8	33		Thu Jun 25 12:01:11 1998  K. Nonobe and T. Ibaraki
22	9	34		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
22	10	23		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
23	1	25		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
23	2	33		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
23	3	23		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
23	4	24		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
23	5	32		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
23	6	27		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
23	7	24		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
23	8	23		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
23	9	26		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
23	10	21		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
24	1	27		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
24	2	31		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
24	3	21		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
24	4	29		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
24	5	37		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
24	6	30		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
24	7	29		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
24	8	38		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
24	9	31		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
24	10	37		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
25	1	34		Sat Aug 30 04:17:51 1997  Soenke Hartmann
25	2	32		Thu Jun 25 12:01:16 1998  K. Nonobe and T. Ibaraki
25	3	24		Sat Aug 30 04:18:01 1997  Soenke Hartmann
25	4	30		Sat Aug 30 04:18:05 1997  Soenke Hartmann
25	5	27		Sat Aug 30 04:18:10 1997  Soenke Hartmann
25	6	32		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
25	7	33		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
25	8	33		Sat Aug 30 04:18:14 1997  Soenke Hartmann
25	9	51		Mon Sep  8 12:01:46 1997  Soenke Hartmann
25	10	27		Mon Sep  8 12:01:51 1997  Soenke Hartmann
26	1	21		Sat Aug 30 04:18:26 1997  Soenke Hartmann
26	2	22		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
26	3	42		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
26	4	34		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
26	5	22		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
26	6	29		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
26	7	29		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
26	8	40		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
26	9	21		Sat Aug 30 04:18:31 1997  Soenke Hartmann
26	10	22		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
27	1	38		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
27	2	29		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
27	3	28		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
27	4	28		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
27	5	40		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
27	6	25		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
27	7	30		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
27	8	42		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
27	9	37		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
27	10	29		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
28	1	37		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
28	2	25		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
28	3	31		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
28	4	33		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
28	5	23		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
28	6	29		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
28	7	37		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
28	8	36		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
28	9	28		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
28	10	26		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
29	1	46		Thu Dec 17 04:26:11 1998  Soenke Hartmann
29	2	34		Mon Jun  9 11:50:08 2008  J. Coelho and M. Vanhoucke
29	3	32		Fri Oct 31 12:01:00 1997  K.Bouleimen
29	4	33		Fri Oct 31 12:01:08 1997  K.Bouleimen
29	5	34		Thu Jun 25 12:06:33 1998  K. Nonobe and T. Ibaraki
29	6	42		Thu Sep 24 10:35:22 1998  K. Nonobe and T. Ibaraki
29	7	38		Thu Jun 25 12:01:29 1998  K. Nonobe and T. Ibaraki
29	8	50		Thu Sep 24 10:35:32 1998  K. Nonobe and T. Ibaraki
29	9	37		Thu Jun 25 12:01:38 1998  K. Nonobe and T. Ibaraki
29	10	36		Thu Jun 25 12:01:25 1998  K. Nonobe and T. Ibaraki
30	1	36		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
30	2	30		Thu Jun 25 12:01:47 1998  K. Nonobe and T. Ibaraki
30	3	29		Sat Aug 30 04:19:21 1997  Soenke Hartmann
30	4	35		Mon Sep  8 12:02:34 1997  Soenke Hartmann
30	5	30		Sat Aug 30 04:19:30 1997  Soenke Hartmann
30	6	41		Sat Aug 30 04:19:36 1997  Soenke Hartmann
30	7	27		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
30	8	28		Mon Sep  8 12:02:38 1997  Soenke Hartmann
30	9	36		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
30	10	19		Thu Jun 25 12:01:43 1998  K. Nonobe and T. Ibaraki
31	1	25		Mon Sep  8 12:02:44 1997  Soenke Hartmann
31	2	43		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
31	3	31		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
31	4	29		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
31	5	43		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
31	6	32		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
31	7	45		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
31	8	26		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
31	9	33		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
31	10	20		Sat Aug 30 04:19:52 1997  Soenke Hartmann
32	1	31		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
32	2	32		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
32	3	28		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
32	4	27		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
32	5	29		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
32	6	29		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
32	7	36		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
32	8	29		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
32	9	22		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
32	10	29		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
33	1	47		Fri Jan 22 04:00:06 1999  K. Nonobe and T. Ibaraki
33	2	45		Thu Jun 10 04:00:15 1999  M. Mika
33	3	45		Thu Jun 25 12:07:09 1998  K. Nonobe and T. Ibaraki
33	4	57		Thu Jun 25 12:01:56 1998  K. Nonobe and T. Ibaraki
33	5	48		Thu Jun 10 04:00:19 1999  M. Mika
33	6	41		Thu Jun 25 12:02:01 1998  K. Nonobe and T. Ibaraki
33	7	45		Thu Jun 10 04:00:24 1999  M. Mika
33	8	39		Thu Jun 25 12:07:23 1998  K. Nonobe and T. Ibaraki
33	9	44		Thu Sep 24 10:35:45 1998  K. Nonobe and T. Ibaraki
33	10	39		Thu Jun 10 04:00:10 1999  M. Mika
34	1	39		Thu Jun 25 12:02:06 1998  K. Nonobe and T. Ibaraki
34	2	32		Thu Jun 25 12:02:10 1998  K. Nonobe and T. Ibaraki
34	3	38		Sat Aug 30 04:20:51 1997  Soenke Hartmann
34	4	42		Sat Aug 30 04:20:55 1997  Soenke Hartmann
34	5	43		Mon Sep  8 12:03:12 1997  Soenke Hartmann
34	6	41		Thu Jun 25 12:02:15 1998  K. Nonobe and T. Ibaraki
34	7	44		Mon Sep  8 12:03:21 1997  Soenke Hartmann
34	8	47		Sat Aug 30 04:21:14 1997  Soenke Hartmann
34	9	38		Mon Sep  8 12:03:30 1997  Soenke Hartmann
34	10	54		Thu Sep 24 10:35:52 1998  K. Nonobe and T. Ibaraki
35	1	34		Thu Jun 10 04:00:28 1999  M. Mika
35	2	35		Thu Jun 25 12:02:19 1998  K. Nonobe and T. Ibaraki
35	3	39		Sat Aug 30 04:21:37 1997  Soenke Hartmann
35	4	47		Mon Sep  8 12:03:47 1997  Soenke Hartmann
35	5	42		Sat Aug 30 04:21:46 1997  Soenke Hartmann
35	6	41		Sat Aug 30 04:21:51 1997  Soenke Hartmann
35	7	35		Mon Sep  8 12:03:52 1997  Soenke Hartmann
35	8	40		Mon Sep  8 12:03:57 1997  Soenke Hartmann
35	9	36		Sat Aug 30 04:22:05 1997  Soenke Hartmann
35	10	51		Mon Sep  8 12:04:02 1997  Soenke Hartmann
37	1	54		Thu Jun 10 04:00:32 1999  M. Mika
37	2	58		Thu Jun 10 04:00:37 1999  M. Mika
37	3	56		Thu Jun 25 12:07:46 1998  K. Nonobe and T. Ibaraki
37	4	54		Thu Sep 24 10:36:09 1998  K. Nonobe and T. Ibaraki
37	5	51		Thu Jun 25 12:07:56 1998  K. Nonobe and T. Ibaraki
37	6	62		Thu Sep 24 10:36:17 1998  K. Nonobe and T. Ibaraki
37	7	57		Thu Dec 17 04:31:47 1998  Soenke Hartmann
37	8	44		Thu Sep 24 10:36:24 1998  K. Nonobe and T. Ibaraki
37	9	59		Thu Jun 10 04:00:41 1999  M. Mika
37	10	42		Thu Dec 17 04:32:00 1998  Soenke Hartmann
38	1	46		Fri Oct 31 12:01:46 1997  K.Bouleimen
38	2	44		Thu Jun 25 12:08:18 1998  K. Nonobe and T. Ibaraki
38	3	34		Thu Jun 25 12:08:23 1998  K. Nonobe and T. Ibaraki
38	4	50		Thu Jun 10 04:00:46 1999  M. Mika
38	5	50		Thu Jun 25 12:02:37 1998  K. Nonobe and T. Ibaraki
38	6	36		Mon Jun  9 11:50:08 2008  J. Coelho and M. Vanhoucke
38	7	38		Thu Dec 17 04:32:32 1998  Soenke Hartmann
38	8	40		Mon Sep  8 12:05:26 1997  Soenke Hartmann
38	9	45		Thu Dec 17 04:32:41 1998  Soenke Hartmann
38	10	37		Mon Sep  8 12:05:36 1997  Soenke Hartmann
39	1	43		Sat Aug 30 04:23:36 1997  Soenke Hartmann
39	2	42		Thu Dec 17 04:32:55 1998  Soenke Hartmann
39	3	49		Thu Sep 24 10:36:30 1998  K. Nonobe and T. Ibaraki
39	4	49		Thu Jun 25 12:02:42 1998  K. Nonobe and T. Ibaraki
39	5	32		Thu Sep 24 10:36:39 1998  K. Nonobe and T. Ibaraki
39	6	36		Thu Jun 25 12:02:46 1998  K. Nonobe and T. Ibaraki
39	7	38		Thu Jun 25 12:02:51 1998  K. Nonobe and T. Ibaraki
39	8	42		Thu Dec 17 04:33:26 1998  Soenke Hartmann
39	9	42		Thu Jun 25 12:03:01 1998  K. Nonobe and T. Ibaraki
39	10	44		Thu Dec 17 04:33:34 1998  Soenke Hartmann
40	1	38		Mon Sep  8 12:06:09 1997  Soenke Hartmann
40	2	41		Sat Aug 30 04:24:22 1997  Soenke Hartmann
40	3	36		Thu Jun 25 12:03:06 1998  K. Nonobe and T. Ibaraki
40	4	40		Thu Sep 24 10:36:47 1998  K. Nonobe and T. Ibaraki
40	5	48		Sat Aug 30 04:24:36 1997  Soenke Hartmann
40	6	41		Fri Oct 31 12:02:00 1997  K.Bouleimen
40	7	48		Mon Sep  8 12:06:14 1997  Soenke Hartmann
40	8	41		Mon Sep  8 12:06:18 1997  Soenke Hartmann
40	9	43		Sat Aug 30 04:24:54 1997  Soenke Hartmann
40	10	44		Sat Aug 30 04:24:58 1997  Soenke Hartmann
41	1	35		Mon Sep  8 12:06:23 1997  Soenke Hartmann
41	2	34		Fri Jan 22 12:00:10 1999  K. Nonobe and T. Ibaraki
41	3	40		Fri Oct 31 12:02:05 1997  K.Bouleimen
41	4	33		Mon Sep  8 12:06:39 1997  Soenke Hartmann
41	5	37		Thu Dec 17 04:34:42 1998  Soenke Hartmann
41	6	32		Thu Dec 17 04:34:46 1998  Soenke Hartmann
41	7	39		Thu Jun 10 04:00:50 1999  M. Mika
41	8	30		Thu Jun 25 12:03:15 1998  K. Nonobe and T. Ibaraki
41	9	42		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
41	10	38		Thu Sep 24 10:36:52 1998  K. Nonobe and T. Ibaraki
42	1	35		Thu Jun 25 12:09:14 1998  K. Nonobe and T. Ibaraki
42	2	26		Mon Sep  8 12:07:02 1997  Soenke Hartmann
42	3	37		Sat Aug 30 04:25:53 1997  Soenke Hartmann
42	4	28		Sat Aug 30 04:25:58 1997  Soenke Hartmann
42	5	35		Sat Aug 30 04:26:03 1997  Soenke Hartmann
42	6	30		Mon Sep  8 12:07:07 1997  Soenke Hartmann
42	7	29		Thu Jun 10 04:00:54 1999  M. Mika
42	8	28		Mon Sep  8 12:07:11 1997  Soenke Hartmann
42	9	31		Sat Aug 30 04:26:21 1997  Soenke Hartmann
42	10	36		Thu Sep 24 10:36:59 1998  K. Nonobe and T. Ibaraki
43	1	29		Thu Jun 25 12:09:18 1998  K. Nonobe and T. Ibaraki
43	2	32		Thu Dec 17 04:35:58 1998  Soenke Hartmann
43	3	26		Thu Jun 25 12:09:27 1998  K. Nonobe and T. Ibaraki
43	4	27		Thu Jun 25 12:09:33 1998  K. Nonobe and T. Ibaraki
43	5	44		Sat Aug 30 04:26:48 1997  Soenke Hartmann
43	6	28		Mon Sep  8 12:07:16 1997  Soenke Hartmann
43	7	33		Thu Jun 10 04:00:59 1999  M. Mika
43	8	34		Mon Sep  8 12:07:21 1997  Soenke Hartmann
43	9	38		Thu Jun 25 12:09:37 1998  K. Nonobe and T. Ibaraki
43	10	30		Thu Jun 25 12:09:23 1998  K. Nonobe and T. Ibaraki
44	1	41		Thu Jun 25 12:03:28 1998  K. Nonobe and T. Ibaraki
44	2	27		Thu Jun 25 12:03:33 1998  K. Nonobe and T. Ibaraki
44	3	34		Mon Sep  8 12:07:30 1997  Soenke Hartmann
44	4	33		Sat Aug 30 04:27:29 1997  Soenke Hartmann
44	5	29		Thu Jun 25 12:03:38 1998  K. Nonobe and T. Ibaraki
44	6	25		Sat Aug 30 04:27:39 1997  Soenke Hartmann
44	7	35		Mon Sep  8 12:07:34 1997  Soenke Hartmann
44	8	36		Sat Aug 30 04:27:48 1997  Soenke Hartmann
44	9	35		Thu Jun 25 12:03:42 1998  K. Nonobe and T. Ibaraki
44	10	31		Mon Sep  8 12:07:39 1997  Soenke Hartmann
45	1	40		Thu Sep 24 10:37:06 1998  K. Nonobe and T. Ibaraki
45	2	48		Thu Sep 24 10:37:13 1998  K. Nonobe and T. Ibaraki
45	3	42		Thu Sep 24 10:37:20 1998  K. Nonobe and T. Ibaraki
45	4	50		Thu Jun 25 12:03:56 1998  K. Nonobe and T. Ibaraki
45	5	42		Thu Jun 25 12:10:19 1998  K. Nonobe and T. Ibaraki
45	6	46		Thu Dec 17 04:37:46 1998  Soenke Hartmann
45	7	46		Thu Dec 17 04:37:51 1998  Soenke Hartmann
45	8	48		Thu Jun 10 04:01:04 1999  M. Mika
45	9	42		Thu Jun 10 04:01:09 1999  M. Mika
45	10	42		Thu Dec 17 04:38:04 1998  Soenke Hartmann
46	1	33		Thu Jun 25 12:10:37 1998  K. Nonobe and T. Ibaraki
46	2	40		Thu Dec 17 04:38:13 1998  Soenke Hartmann
46	3	30		Thu Dec 17 04:38:18 1998  Soenke Hartmann
46	4	37		Thu Jun 25 12:04:15 1998  K. Nonobe and T. Ibaraki
46	5	33		Mon Jun  9 11:50:09 2008  J. Coelho and M. Vanhoucke
46	6	33		Thu Dec 17 04:38:31 1998  Soenke Hartmann
46	7	43		Mon Feb  7 08:35:06 2011  L. F. Muller
46	8	33		Thu Sep 24 10:37:36 1998  K. Nonobe and T. Ibaraki
46	9	40		Thu Dec 17 04:38:44 1998  Soenke Hartmann
46	10	37		Thu Jun 10 04:01:13 1999  M. Mika
47	1	39		Sat Aug 30 04:29:33 1997  Soenke Hartmann
47	2	29		Mon Sep  8 12:08:38 1997  Soenke Hartmann
47	3	29		Thu Jun 25 12:04:19 1998  K. Nonobe and T. Ibaraki
47	4	38		Thu Sep 24 10:37:44 1998  K. Nonobe and T. Ibaraki
47	5	26		Thu Jun 25 12:10:55 1998  K. Nonobe and T. Ibaraki
47	6	34		Fri Jan 22 04:00:10 1999  K. Nonobe and T. Ibaraki
47	7	28		Sun Feb  6 23:20:04 2011  L. F. Muller
47	8	38		Mon Sep  8 12:08:52 1997  Soenke Hartmann
47	9	34		Mon Sep  8 12:08:57 1997  Soenke Hartmann
47	10	42		Sat Aug 30 04:30:13 1997  Soenke Hartmann
48	1	28		Sat Aug 30 04:30:19 1997  Soenke Hartmann
48	2	30		Sat Aug 30 04:30:23 1997  Soenke Hartmann
48	3	35		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
48	4	24		Sat Aug 30 04:30:28 1997  Soenke Hartmann
48	5	25		Sat Aug 30 04:30:32 1997  Soenke Hartmann
48	6	31		Mon Sep  8 12:09:02 1997  Soenke Hartmann
48	7	32		Thu Jun 25 12:11:05 1998  K. Nonobe and T. Ibaraki
48	8	28		Mon Sep  8 12:09:06 1997  Soenke Hartmann
48	9	37		Thu Sep 24 10:37:52 1998  K. Nonobe and T. Ibaraki
48	10	28		Thu Jun 25 12:04:25 1998  K. Nonobe and T. Ibaraki
49	1	33		Mon Sep  8 12:09:11 1997  Soenke Hartmann
49	2	49		Thu Sep 24 10:37:59 1998  K. Nonobe and T. Ibaraki
49	3	35		Mon Sep  8 12:09:20 1997  Soenke Hartmann
49	4	37		Wed Jan 20 12:00:05 1999  K. Nonobe and T. Ibaraki
49	5	37		Sat Aug 30 04:31:17 1997  Soenke Hartmann
49	6	31		Thu Sep 24 10:38:06 1998  K. Nonobe and T. Ibaraki
49	7	36		Sat Aug 30 04:31:27 1997  Soenke Hartmann
49	8	34		Mon Sep  8 12:09:24 1997  Soenke Hartmann
49	9	33		Mon Sep  8 12:09:29 1997  Soenke Hartmann
49	10	30		Tue Jun 30 04:00:07 1998  K. Nonobe and T. Ibaraki
50	1	28		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
50	2	37		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
50	3	43		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
50	4	34		Mon Sep  8 12:09:38 1997  Soenke Hartmann
50	5	37		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
50	6	37		Sat Aug 30 04:31:45 1997  Soenke Hartmann
50	7	22		Tue Jun 30 04:00:11 1998  K. Nonobe and T. Ibaraki
50	8	27		Tue Jun 30 04:00:16 1998  K. Nonobe and T. Ibaraki
50	9	25		Sat Aug 30 04:31:59 1997  Soenke Hartmann
50	10	30		Sat Aug 30 04:32:03 1997  Soenke Hartmann
51	1	32		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
51	2	23		Sat Aug 30 04:32:08 1997  Soenke Hartmann
51	3	27		Sat Aug 30 04:32:13 1997  Soenke Hartmann
51	4	51		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
51	5	33		Sat Aug 30 04:32:18 1997  Soenke Hartmann
51	6	38		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
51	7	26		Sat Aug 30 04:32:23 1997  Soenke Hartmann
51	8	33		Sat Aug 30 04:32:27 1997  Soenke Hartmann
51	9	35		Sat Aug 30 04:32:32 1997  Soenke Hartmann
51	10	27		Mon Sep  8 12:09:43 1997  Soenke Hartmann
52	1	32		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
52	2	23		Mon Sep  8 12:09:47 1997  Soenke Hartmann
52	3	22		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
52	4	29		Sat Aug 30 04:32:41 1997  Soenke Hartmann
52	5	30		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
52	6	30		Sat Aug 30 04:32:46 1997  Soenke Hartmann
52	7	30		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
52	8	26		Sat Aug 30 04:32:50 1997  Soenke Hartmann
52	9	31		Sat Aug 30 04:32:55 1997  Soenke Hartmann
52	10	29		Sat Aug 30 04:32:59 1997  Soenke Hartmann
53	1	42		Tue Jun 30 04:00:21 1998  K. Nonobe and T. Ibaraki
53	2	38		Mon Sep  8 12:09:57 1997  Soenke Hartmann
53	3	34		Tue Jun 30 04:00:25 1998  K. Nonobe and T. Ibaraki
53	4	44		Thu Sep 24 10:38:20 1998  K. Nonobe and T. Ibaraki
53	5	49		Tue Jun 30 04:00:30 1998  K. Nonobe and T. Ibaraki
53	6	43		Tue Jun 30 04:00:34 1998  K. Nonobe and T. Ibaraki
53	7	37		Thu Sep 24 10:38:26 1998  K. Nonobe and T. Ibaraki
53	8	38		Mon Jun  9 11:50:09 2008  J. Coelho and M. Vanhoucke
53	9	42		Thu Sep 24 10:38:32 1998  K. Nonobe and T. Ibaraki
53	10	37		Thu Sep 24 10:38:13 1998  K. Nonobe and T. Ibaraki
54	1	33		Sat Aug 30 04:33:50 1997  Soenke Hartmann
54	2	28		Tue Jun 30 04:00:48 1998  K. Nonobe and T. Ibaraki
54	3	22		Tue Jun 30 04:00:52 1998  K. Nonobe and T. Ibaraki
54	4	30		Tue Jun 30 04:00:57 1998  K. Nonobe and T. Ibaraki
54	5	28		Mon Sep  8 12:10:31 1997  Soenke Hartmann
54	6	30		Sat Aug 30 04:34:12 1997  Soenke Hartmann
54	7	39		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
54	8	31		Sat Aug 30 04:34:17 1997  Soenke Hartmann
54	9	28		Thu Sep 24 10:38:38 1998  K. Nonobe and T. Ibaraki
54	10	29		Tue Jun 30 04:01:02 1998  K. Nonobe and T. Ibaraki
55	1	29		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
55	2	31		Sat Aug 30 04:34:31 1997  Soenke Hartmann
55	3	28		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
55	4	41		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
55	5	24		Sat Aug 30 04:34:35 1997  Soenke Hartmann
55	6	25		Sat Aug 30 04:34:40 1997  Soenke Hartmann
55	7	44		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
55	8	44		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
55	9	27		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
55	10	29		Tue Jun 30 04:01:07 1998  K. Nonobe and T. Ibaraki
56	1	21		Tue Jun 30 04:01:12 1998  K. Nonobe and T. Ibaraki
56	2	31		Tue Jun 30 04:01:17 1998  K. Nonobe and T. Ibaraki
56	3	34		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
56	4	32		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
56	5	29		Sat Aug 30 04:34:58 1997  Soenke Hartmann
56	6	26		Sat Aug 30 04:35:03 1997  Soenke Hartmann
56	7	30		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
56	8	29		Sat Aug 30 04:35:07 1997  Soenke Hartmann
56	9	33		Sat Aug 30 04:35:12 1997  Soenke Hartmann
56	10	39		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
57	1	30		Sat Aug 30 04:35:17 1997  Soenke Hartmann
57	2	32		Tue Jun 30 04:01:21 1998  K. Nonobe and T. Ibaraki
57	3	29		Mon Sep  8 12:10:54 1997  Soenke Hartmann
57	4	29		Sat Aug 30 04:35:29 1997  Soenke Hartmann
57	5	27		Sat Aug 30 04:35:33 1997  Soenke Hartmann
57	6	23		Sat Aug 30 04:35:38 1997  Soenke Hartmann
57	7	27		Mon Sep  8 12:10:58 1997  Soenke Hartmann
57	8	29		Sat Aug 30 04:35:46 1997  Soenke Hartmann
57	9	26		Mon Sep  8 12:11:03 1997  Soenke Hartmann
57	10	32		Fri Oct 31 12:02:44 1997  K.Bouleimen
58	1	30		Sat Aug 30 04:35:59 1997  Soenke Hartmann
58	2	32		Sat Aug 30 04:36:04 1997  Soenke Hartmann
58	3	31		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
58	4	27		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
58	5	28		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
58	6	24		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
58	7	26		Sat Aug 30 04:36:08 1997  Soenke Hartmann
58	8	28		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
58	9	30		Sat Aug 30 04:36:13 1997  Soenke Hartmann
58	10	27		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
59	1	24		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
59	2	23		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
59	3	34		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
59	4	25		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
59	5	28		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
59	6	27		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
59	7	34		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
59	8	26		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
59	9	34		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
59	10	29		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
60	1	22		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
60	2	38		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
60	3	39		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
60	4	23		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
60	5	34		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
60	6	36		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
60	7	25		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
60	8	29		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
60	9	31		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
60	10	23		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
61	1	37		Tue Jun 30 04:01:26 1998  K. Nonobe and T. Ibaraki
61	2	36		Tue Jun 30 04:01:31 1998  K. Nonobe and T. Ibaraki
61	3	39		Tue Jun 30 04:01:35 1998  K. Nonobe and T. Ibaraki
61	4	38		Tue Jun 30 04:01:40 1998  K. Nonobe and T. Ibaraki
61	5	39		Fri Jan 22 04:00:15 1999  K. Nonobe and T. Ibaraki
61	6	35		Tue Jun 30 04:01:44 1998  K. Nonobe and T. Ibaraki
61	7	44		Fri Oct 31 12:03:07 1997  K.Bouleimen
61	8	46		Mon Jun  9 11:50:09 2008  J. Coelho and M. Vanhoucke
61	9	44		Tue Jun 30 04:01:53 1998  K. Nonobe and T. Ibaraki
61	10	41		Tue Jun 30 04:01:58 1998  K. Nonobe and T. Ibaraki
62	1	26		Thu Sep 24 10:38:44 1998  K. Nonobe and T. Ibaraki
62	2	33		Tue Jun 30 04:02:03 1998  K. Nonobe and T. Ibaraki
62	3	26		Tue Jun 30 04:02:07 1998  K. Nonobe and T. Ibaraki
62	4	33		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
62	5	42		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
62	6	36		Tue Jun 30 04:02:12 1998  K. Nonobe and T. Ibaraki
62	7	27		Tue Jun 30 04:02:16 1998  K. Nonobe and T. Ibaraki
62	8	38		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
62	9	26		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
62	10	26		Sat Aug 30 04:37:17 1997  Soenke Hartmann
63	1	29		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
63	2	30		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
63	3	24		Sat Aug 30 04:37:24 1997  Soenke Hartmann
63	4	31		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
63	5	37		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
63	6	39		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
63	7	26		Sat Aug 30 04:37:28 1997  Soenke Hartmann
63	8	31		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
63	9	25		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
63	10	27		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
64	1	25		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
64	2	23		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
64	3	34		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
64	4	25		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
64	5	36		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
64	6	29		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
64	7	34		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
64	8	23		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
64	9	31		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
64	10	36		Sa  Apr  6 17:50:00 1996  R. Kolisch / A. Drexl
